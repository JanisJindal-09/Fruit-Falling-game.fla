using UnityEngine;

public class Fruit : MonoBehaviour
{
    public float fallSpeed = 2.5f;

    void Update()
    {
        transform.Translate(Vector3.down * fallSpeed * Time.deltaTime);

        if (transform.position.y < -6f)
        {
            Destroy(gameObject);
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            // Add score logic here
            Destroy(gameObject);
        }
    }
}
