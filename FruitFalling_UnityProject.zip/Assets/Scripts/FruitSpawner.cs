using UnityEngine;

public class FruitSpawner : MonoBehaviour
{
    public GameObject[] fruitPrefabs;
    public float spawnInterval = 1.0f;
    public float spawnXRange = 2.5f;
    public float startY = 6.0f;

    private float timer = 0f;

    void Update()
    {
        timer += Time.deltaTime;
        if (timer >= spawnInterval)
        {
            SpawnFruit();
            timer = 0f;
        }
    }

    void SpawnFruit()
    {
        if (fruitPrefabs == null || fruitPrefabs.Length == 0) return;
        int idx = Random.Range(0, fruitPrefabs.Length);
        Vector3 pos = new Vector3(Random.Range(-spawnXRange, spawnXRange), startY, 0f);
        Instantiate(fruitPrefabs[idx], pos, Quaternion.identity);
    }
}
